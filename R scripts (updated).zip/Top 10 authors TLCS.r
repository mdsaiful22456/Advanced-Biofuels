# Loading required libraries
library(readxl)
library(dplyr)
library(tidyr)

# Reading the Excel file (Sheet1)
excel_data <- read_excel("Most_Local_Cited_Documents_bibliometrix_2025-05-17.xlsx", sheet = "Sheet1")

# Reading the CSV data
csv_data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)

# Cleaning DOIs in both datasets (convert to lowercase, remove trailing/leading spaces)
excel_data <- excel_data %>%
  mutate(DOI = tolower(trimws(DOI)))
csv_data <- csv_data %>%
  mutate(DOI = tolower(trimws(DOI)))

# Selecting relevant columns from Excel data
excel_citations <- excel_data %>%
  select(DOI, Local_Citations = `Local Citations`) %>%
  filter(!is.na(DOI), !is.na(Local_Citations))

# Splitting Authors in CSV data and creating one row per author per DOI
author_data <- csv_data %>%
  mutate(Authors = strsplit(Authors, ";\\s*")) %>%
  unnest(Authors) %>%
  rename(Author = Authors) %>%
  select(Author, DOI) %>%
  filter(!is.na(DOI))

# List of top 10 authors
top_10_authors <- c(
  "Simmons B.A.", "Keasling J.D.", "Monti A.", "Chiaramonti D.", 
  "Zhang Y.", "Liu Y.", "Zegada-Lizarazu W.", "Bonomi A.", 
  "Lapuerta M.", "Lee T.S."
)

# Joining author data with local citations by DOI
author_citations <- author_data %>%
  inner_join(excel_citations, by = "DOI") %>%
  filter(Author %in% top_10_authors)

# Calculating TLCS (sum of local citations) for each top 10 author
tlcs_results <- author_citations %>%
  group_by(Author) %>%
  summarise(TLCS = sum(Local_Citations)) %>%
  arrange(match(Author, top_10_authors))  # Maintain order of provided list

# Handling authors with no matched DOIs (TLCS = 0)
missing_authors <- top_10_authors[!top_10_authors %in% tlcs_results$Author]
if (length(missing_authors) > 0) {
  missing_df <- data.frame(
    Author = missing_authors,
    TLCS = 0
  )
  tlcs_results <- bind_rows(tlcs_results, missing_df) %>%
    arrange(match(Author, top_10_authors))
}

# Printing the results
print("TLCS for Top 10 Authors:")
print(tlcs_results)

# Saving the results to a CSV file
write.csv(tlcs_results, "tlcs_top_10_authors.csv", row.names = FALSE)