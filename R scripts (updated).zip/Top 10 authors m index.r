# Loading required libraries
library(dplyr)
library(tidyr)

# Reading the CSV data
data <- read.csv("advanced_biofuel.csv", stringsAsFactors = FALSE)

# Splitting Authors and creating one row per author per article
author_data <- data %>%
  mutate(Authors = strsplit(Authors, ";\\s*")) %>%
  unnest(Authors) %>%
  rename(Author = Authors) %>%
  select(Author, Cited.by, Year) %>%
  filter(!is.na(Cited.by), !is.na(Year))  # Remove rows with missing citations or year

# List of top 10 authors
top_10_authors <- c(
  "Simmons B.A.", "Keasling J.D.", "Monti A.", "Chiaramonti D.", 
  "Zhang Y.", "Liu Y.", "Zegada-Lizarazu W.", "Bonomi A.", 
  "Lapuerta M.", "Lee T.S."
)

# Function to calculate h-index
calculate_h_index <- function(citations) {
  citations <- sort(citations, decreasing = TRUE)
  h <- 0
  for (i in seq_along(citations)) {
    if (citations[i] >= i) {
      h <- i
    } else {
      break
    }
  }
  return(h)
}

# Calculating h-index and earliest publication year
author_metrics <- author_data %>%
  filter(Author %in% top_10_authors) %>%
  group_by(Author) %>%
  summarise(
    H_Index = calculate_h_index(Cited.by),
    First_Year = min(Year)
  )

# Calculating m-index (h-index / years since first publication)
current_year <- 2025
m_index_results <- author_metrics %>%
  mutate(
    Years_Since_First = current_year - First_Year,
    M_Index = H_Index / Years_Since_First
  ) %>%
  select(Author, H_Index, First_Year, Years_Since_First, M_Index) %>%
  arrange(match(Author, top_10_authors))  # Maintain order of provided list

# Printing the results
print("M-Index for Top 10 Authors:")
print(m_index_results)

# Saving the results to a CSV file
write.csv(m_index_results, "m_index_top_10_authors.csv", row.names = FALSE)