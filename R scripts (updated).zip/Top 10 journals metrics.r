# Loading required libraries
library(readxl)
library(dplyr)
library(tidyr)

# Reading the datasets
csv_data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)
excel_data <- read_excel("Most_Local_Cited_Documents_bibliometrix_2025-05-17.xlsx", sheet = "Sheet1")

# Cleaning data
csv_data <- csv_data %>%
  mutate(
    Source_title = trimws(toupper(Source.title)),  # Standardize journal names
    DOI = tolower(trimws(DOI)),                    # Standardize DOIs
    Cited.by = as.numeric(Cited.by),               # Ensure numeric citations
    Year = as.integer(Year)                        # Ensure integer year
  ) %>%
  filter(!is.na(Source_title), !is.na(Cited.by), !is.na(Year))

excel_data <- excel_data %>%
  mutate(DOI = tolower(trimws(DOI))) %>%
  select(DOI, Local_Citations = `Local Citations`) %>%
  filter(!is.na(DOI), !is.na(Local_Citations))

# Total number of articles
total_articles <- 767

# Function to calculate h-index
calculate_h_index <- function(citations) {
  citations <- sort(citations, decreasing = TRUE)
  h <- 0
  for (i in seq_along(citations)) {
    if (citations[i] >= i) {
      h <- i
    } else {
      break
    }
  }
  return(h)
}

# Function to calculate g-index
calculate_g_index <- function(citations) {
  citations <- sort(citations, decreasing = TRUE)
  cumsum_citations <- cumsum(citations)
  g <- 0
  for (i in seq_along(citations)) {
    if (cumsum_citations[i] >= i^2) {
      g <- i
    } else {
      break
    }
  }
  return(g)
}

# Calculating journal metrics
journal_metrics <- csv_data %>%
  group_by(Source_title) %>%
  summarise(
    Num_Articles = n(),
    Percentage_Contribution = (Num_Articles / total_articles) * 100,
    H_Index = calculate_h_index(Cited.by),
    G_Index = calculate_g_index(Cited.by),
    First_Year = min(Year),
    TGCS = sum(Cited.by)
  ) %>%
  mutate(
    Years_Since_First = 2025 - First_Year,
    M_Index = if_else(Years_Since_First > 0, H_Index / Years_Since_First, 0)
  )

# Calculating TLCS by matching DOIs
journal_tlcs <- csv_data %>%
  select(Source_title, DOI) %>%
  inner_join(excel_data, by = "DOI") %>%
  group_by(Source_title) %>%
  summarise(TLCS = sum(Local_Citations))

# Merging TLCS with other metrics
journal_metrics <- journal_metrics %>%
  left_join(journal_tlcs, by = "Source_title") %>%
  mutate(TLCS = if_else(is.na(TLCS), 0, TLCS))  # Set TLCS to 0 for journals with no matched DOIs

# Selecting top 10 journals by number of articles
top_10_journals <- journal_metrics %>%
  arrange(desc(Num_Articles)) %>%
  slice_head(n = 10) %>%
  select(
    Source_title,
    Num_Articles,
    Percentage_Contribution,
    H_Index,
    G_Index,
    M_Index,
    TGCS,
    TLCS
  )

# Printing the results
print("Top 10 Journals Metrics:")
print(top_10_journals)

# Saving the results to a CSV file
write.csv(top_10_journals, "top_10_journals_metrics.csv", row.names = FALSE)