# Loading required libraries
library(readxl)
library(dplyr)
library(tidyr)

# Reading the datasets
csv_data <- read.csv("advanced biofuel_refined.csv", stringsAsFactors = FALSE)
excel_data <- read_excel("Most_Local_Cited_Documents_bibliometrix_2025-05-17.xlsx", sheet = "Sheet1")

# Cleaning data
csv_data <- csv_data %>%
  mutate(
    Country = trimws(Country),                    # Remove extra spaces
    Affiliation = trimws(Affiliation),            # Remove extra spaces
    DOI = tolower(trimws(DOI)),                  # Standardize DOIs
    Cited.by = as.numeric(Cited.by)              # Ensure numeric citations
  ) %>%
  filter(
    !is.na(Cited.by),                            # Remove rows with missing citations
    !is.na(DOI),                                 # Remove rows with missing DOI
    !is.na(Country) & Country != "",             # Remove NA or empty Country
    !is.na(Affiliation) & Affiliation != ""      # Remove NA or empty Affiliation
  ) %>%
  mutate(Cited.by = if_else(is.na(Cited.by), 0, Cited.by))  # Set invalid citations to 0

excel_data <- excel_data %>%
  mutate(DOI = tolower(trimws(DOI))) %>%
  select(DOI, Local_Citations = `Local Citations`) %>%
  filter(!is.na(DOI), !is.na(Local_Citations))

# Total number of articles
total_articles <- nrow(csv_data)

# --- Country Metrics ---
# Calculating metrics by Country
country_metrics <- csv_data %>%
  group_by(Country) %>%
  summarise(
    Num_Articles = n(),
    Percentage_Contribution = (Num_Articles / total_articles) * 100,
    TGCS = sum(Cited.by)
  )

# Calculating TLCS by matching DOIs
country_tlcs <- csv_data %>%
  select(Country, DOI) %>%
  inner_join(excel_data, by = "DOI") %>%
  group_by(Country) %>%
  summarise(TLCS = sum(Local_Citations))

# Merging TLCS with other metrics
country_metrics <- country_metrics %>%
  left_join(country_tlcs, by = "Country") %>%
  mutate(TLCS = if_else(is.na(TLCS), 0, TLCS))  # Set TLCS to 0 for countries with no matched DOIs

# Sorting by number of articles
country_metrics <- country_metrics %>%
  arrange(desc(Num_Articles))

# --- Affiliation Metrics ---
# Calculating metrics by Affiliation
affiliation_metrics <- csv_data %>%
  distinct(Affiliation, DOI, .keep_all = TRUE) %>%  # Avoid double-counting affiliations per article
  group_by(Affiliation) %>%
  summarise(
    Num_Articles = n(),
    Percentage_Contribution = (Num_Articles / total_articles) * 100,
    TGCS = sum(Cited.by)
  )

# Calculating TLCS by matching DOIs
affiliation_tlcs <- csv_data %>%
  distinct(Affiliation, DOI, .keep_all = TRUE) %>%
  select(Affiliation, DOI) %>%
  inner_join(excel_data, by = "DOI") %>%
  group_by(Affiliation) %>%
  summarise(TLCS = sum(Local_Citations))

# Merging TLCS with other metrics
affiliation_metrics <- affiliation_metrics %>%
  left_join(affiliation_tlcs, by = "Affiliation") %>%
  mutate(TLCS = if_else(is.na(TLCS), 0, TLCS))  # Set TLCS to 0 for affiliations with no matched DOIs

# Sorting by number of articles
affiliation_metrics <- affiliation_metrics %>%
  arrange(desc(Num_Articles))

# Printing results
print("Country Metrics (Top 10):")
print(head(country_metrics, 10))

print("Affiliation Metrics (Top 10):")
print(head(affiliation_metrics, 10))

# Saving results to CSV files
write.csv(country_metrics, "country_metrics.csv", row.names = FALSE)
write.csv(affiliation_metrics, "affiliation_metrics.csv", row.names = FALSE)