# Loading required library for data manipulation
library(dplyr)
library(tidyr)

# Reading the CSV data
data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)

# Splitting the Authors column and counting authors per article
data$Author_Count <- sapply(strsplit(data$Authors, ";\\s*"), length)

# Creating a data frame with one row per author per publication
authors_split <- data %>%
  mutate(Authors = strsplit(Authors, ";\\s*")) %>%
  unnest(Authors) %>%
  rename(Author = Authors) %>%
  mutate(Fractional_Value = 1 / Author_Count)

# Summing fractional values per author
fractional_counts <- authors_split %>%
  group_by(Author) %>%
  summarise(Total_Fractional_Value = sum(Fractional_Value)) %>%
  arrange(desc(Total_Fractional_Value))

# Filtering for the top 10 authors provided
top_10_authors <- c(
  "Simmons B.A.", "Keasling J.D.", "Monti A.", "Chiaramonti D.", 
  "Zhang Y.", "Liu Y.", "Zegada-Lizarazu W.", "Bonomi A.", 
  "Lapuerta M.", "Lee T.S."
)
fractional_top_10 <- fractional_counts %>%
  filter(Author %in% top_10_authors) %>%
  arrange(match(Author, top_10_authors))  # Maintain order of provided list

# Printing the results
print("Fractionalized Values for Top 10 Authors:")
print(fractional_top_10)

# Saving the results to a CSV file
write.csv(fractional_top_10, "fractional_top_10_authors.csv", row.names = FALSE)