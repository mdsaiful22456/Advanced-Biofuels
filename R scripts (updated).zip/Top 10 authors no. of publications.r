# Loading required library for data manipulation
library(dplyr)

# Reading the CSV data
# Assuming the data is saved as 'advanced biofuel.csv'
data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)

# Splitting the Authors column into individual authors
# The Authors column contains names separated by semicolons
authors_list <- strsplit(data$Authors, ";\\s*")

# Creating a data frame with one row per author per publication
author_pubs <- data.frame(
  Author = unlist(authors_list),
  Publication = rep(1, length(unlist(authors_list)))
)

# Counting publications per author
author_counts <- author_pubs %>%
  group_by(Author) %>%
  summarise(Publications = n()) %>%
  arrange(desc(Publications))

# Selecting top 10 authors
top_10_authors <- head(author_counts, 10)

# Printing the results
print("Top 10 Authors by Number of Publications:")
print(top_10_authors)

# Optionally, saving the results to a CSV file
write.csv(top_10_authors, "top_10_authors.csv", row.names = FALSE)