# Loading required libraries
library(dplyr)
library(tidyr)

# Reading the CSV data
data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)

# Splitting Authors and creating one row per author per article
author_citations <- data %>%
  mutate(Authors = strsplit(Authors, ";\\s*")) %>%
  unnest(Authors) %>%
  rename(Author = Authors) %>%
  select(Author, Cited.by) %>%
  filter(!is.na(Cited.by))  # Remove rows with missing citations

# List of top 10 authors
top_10_authors <- c(
  "Simmons B.A.", "Keasling J.D.", "Monti A.", "Chiaramonti D.", 
  "Zhang Y.", "Liu Y.", "Zegada-Lizarazu W.", "Bonomi A.", 
  "Lapuerta M.", "Lee T.S."
)

# Function to calculate h-index
calculate_h_index <- function(citations) {
  citations <- sort(citations, decreasing = TRUE)
  h <- 0
  for (i in seq_along(citations)) {
    if (citations[i] >= i) {
      h <- i
    } else {
      break
    }
  }
  return(h)
}

# Calculating h-index for each top 10 author
h_index_results <- author_citations %>%
  filter(Author %in% top_10_authors) %>%
  group_by(Author) %>%
  summarise(H_Index = calculate_h_index(Cited.by)) %>%
  arrange(match(Author, top_10_authors))  # Maintain order of provided list

# Printing the results
print("H-Index for Top 10 Authors:")
print(h_index_results)

# Saving the results to a CSV file
write.csv(h_index_results, "h_index_top_10_authors.csv", row.names = FALSE)