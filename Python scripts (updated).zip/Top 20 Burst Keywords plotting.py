import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
import io

# CSV data from the provided biofuel dataset
csv_data = """Keyword,Start,End,Strength,Recent Frequency
GHG emission,2017,2024,39.00073625,65
Anaerobic digestion,2013,2024,35.48179944,48
Carbon,2015,2024,33.57053382,45
Saccharomyces cerevisiae,2014,2021,31.03579715,43
Fatty acid,2012,2021,26.13705847,81
Wheat straw,2019,2024,22.70228507,35
Hydrothermal liquefaction,2014,2024,21.68645803,35
Gene expression,2010,2018,20.97910863,6
E. coli,2011,2018,20.32432734,5
Techno-economic analysis,2015,2024,19.66274124,26
Yeast,2011,2017,19.60616311,17
Fuels,2013,2018,18.81046477,2
Methane,2015,2018,18.50853599,10
Synthetic biology,2014,2016,18.48392481,5
Algae,2011,2019,17.90899517,5
Clostridium acetobutylicum,2015,2018,17.70381704,19
Diethyl ether,2023,2024,17.57779662,17
Chemistry,2012,2017,17.51319134,10
Energy independence,2008,2013,17.51319134,5
License mdpi,2018,2022,17.2008909,23
"""

# Read CSV data
df = pd.read_csv(io.StringIO(csv_data))

# Sort by Start year
df = df.sort_values(by='Start')

# Extract data
keywords = df['Keyword'].tolist()
starts = df['Start'].tolist()
ends = df['End'].tolist()
frequencies = df['Recent Frequency'].tolist()

# Prepare y positions
n = len(keywords)
y_pos = list(range(n))

# Normalize frequencies for color mapping
min_freq = min(frequencies)
max_freq = max(frequencies)
norm = Normalize(vmin=min_freq, vmax=max_freq)
cmap = plt.cm.viridis
colors = [cmap(norm(freq)) for freq in frequencies]

# Create figure and axis
fig, ax = plt.subplots(figsize=(12, 10))

# Plot burst periods: lines for multi-year bursts, points for single-year bursts
for i in range(n):
    if starts[i] == ends[i]:
        # Single-year burst: plot as a point
        ax.plot(starts[i], y_pos[i], 'o', color=colors[i], markersize=8)
    else:
        # Multi-year burst: plot as a line
        ax.hlines(y_pos[i], starts[i], ends[i], color=colors[i], linewidth=2)

# Set y-ticks to keywords
ax.set_yticks(y_pos)
ax.set_yticklabels(keywords)

# Set x-limits to cover the range of years
min_year = min(starts) - 1
max_year = max(ends) + 1
ax.set_xlim(min_year, max_year)

# Set x-ticks every 2 years
years = list(range(min_year, max_year + 1, 2))
ax.set_xticks(years)

# Add grid lines for x-axis
ax.grid(True, axis='x')

# Add colorbar for frequency
sm = ScalarMappable(norm=norm, cmap=cmap)
sm.set_array([])
cbar = plt.colorbar(sm, ax=ax)
cbar.set_label('Recent Frequency')

# Set title and labels
ax.set_title('Burst Keywords Analysis on Advanced Biofuels Research')
ax.set_xlabel('Year')
ax.set_ylabel('Keywords')

# Adjust layout
plt.tight_layout()

# Save the plot to a file
plt.savefig('biofuel_burst_keywords_analysis.png', dpi=1200)