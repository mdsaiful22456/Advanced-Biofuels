import pandas as pd
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import hdbscan
import umap
import matplotlib.pyplot as plt
from prophet import Prophet
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import re
import warnings
import time
import os
from google.colab import files
from google.colab import drive

# Suppress warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message="n_jobs value .* overridden to 1 by setting random_state")

# Verify umap-learn installation
try:
    from umap import UMAP
except ImportError:
    raise ImportError("The 'umap-learn' package is not installed. Please install it using: pip install umap-learn")

# Cluster names
cluster_names = {
    0: "Biofuel Policy and Sustainability",
    1: "Advanced Biofuel Production Technologies",
    2: "Innovative Biofuel Processing and Engineering"
}

# Step 1: Load dataset and perform clustering
df = pd.read_csv('advanced biofuel.csv', low_memory=False)

# Ensure 'Year' is numeric and handle missing values
df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
df = df.dropna(subset=['Year'])
df.loc[:, 'Year'] = df['Year'].astype(int)

# Validate Year data
if df['Year'].empty:
    raise ValueError("No valid 'Year' data found after cleaning. Please check the 'Year' column in 'advanced biofuel.csv'.")
print("Year column summary:")
print(df['Year'].describe())

# Combine relevant textual fields for analysis
df.loc[:, 'combined_text'] = df['Title'].fillna('') + ' ' + df['Abstract'].fillna('') + ' ' + df['Author Keywords'].fillna('')

# Minimal preprocessing function (SciBERT handles most text processing)
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\s+', ' ', text.strip())  # Normalize whitespace
    return text

# Apply preprocessing
df.loc[:, 'processed_text'] = df['combined_text'].apply(preprocess_text)

# Load SciBERT tokenizer and model
tokenizer = AutoTokenizer.from_pretrained('allenai/scibert_scivocab_uncased')
model = AutoModel.from_pretrained('allenai/scibert_scivocab_uncased')

# Function to get SciBERT embeddings
def get_scibert_embeddings(texts, batch_size=8, device='cpu'):
    embeddings = []
    model.to(device)
    model.eval()
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]
        inputs = tokenizer(batch_texts, return_tensors='pt', truncation=True, padding=True, max_length=512)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs)
        batch_embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
        embeddings.append(batch_embeddings)
    return np.vstack(embeddings)

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Get SciBERT embeddings
texts = df['processed_text'].tolist()
embeddings = get_scibert_embeddings(texts, device=device)

# Standardize embeddings
scaler = StandardScaler()
embeddings_scaled = scaler.fit_transform(embeddings)

# Reduce dimensionality with UMAP
umap_reducer = UMAP(n_components=2, random_state=42, n_neighbors=30, min_dist=0.3)
umap_embeddings = umap_reducer.fit_transform(embeddings_scaled)

# Cluster with HDBSCAN
clusterer = hdbscan.HDBSCAN(min_cluster_size=2, min_samples=2, cluster_selection_epsilon=0.7)
clusters = clusterer.fit_predict(umap_embeddings)

# Post-process to assign noise points to nearest cluster
def assign_noise_to_clusters(clusters, umap_embeddings):
    if -1 in clusters:
        noise_indices = np.where(clusters == -1)[0]
        if len(noise_indices) > 0:
            valid_clusters = np.unique(clusters[clusters != -1])
            if len(valid_clusters) == 0:
                return clusters
            centroids = {c: np.mean(umap_embeddings[clusters == c], axis=0) for c in valid_clusters}
            for idx in noise_indices:
                distances = [np.linalg.norm(umap_embeddings[idx] - centroids[c]) for c in valid_clusters]
                nearest_cluster = valid_clusters[np.argmin(distances)]
                clusters[idx] = nearest_cluster
    return clusters

# Apply noise reassignment
clusters = assign_noise_to_clusters(clusters, umap_embeddings)

# Add cluster labels to DataFrame
df['cluster'] = clusters

# Save clustered DataFrame to a new CSV
df.to_csv('advanced_biofuel_clustered.csv', index=False)
print("Clustered DataFrame saved to: advanced_biofuel_clustered.csv")

# Step 2: Create pub_counts dataframe
min_year = df['Year'].min()
max_year = df['Year'].max()
if pd.isna(min_year) or pd.isna(max_year):
    print("Warning: Invalid min_year or max_year. Using fallback range 2000-2024.")
    min_year = 2000
    max_year = 2024
else:
    min_year = int(min_year)
    max_year = int(min(max_year, 2024))  # Cap at 2024 for historical data
year_range = range(min_year, max_year + 1)

# Compute publication counts per year for each cluster
pub_counts = pd.DataFrame({'Year': year_range})
for cluster_id, cluster_name in cluster_names.items():
    cluster_data = df[df['cluster'] == cluster_id].groupby('Year').size().reindex(year_range, fill_value=0)
    # Smooth data for Cluster 0
    if cluster_name == "Biofuel Policy and Sustainability":
        print(f"\nHistorical counts for {cluster_name}:")
        print(cluster_data.to_dict())
        cluster_data = cluster_data.rolling(window=7, min_periods=1, center=True).mean().fillna(0).round()
        print(f"Smoothed counts for {cluster_name}:")
        print(cluster_data.to_dict())
    pub_counts[cluster_name] = cluster_data.values

# Step 3: Prepare data for Prophet
def prepare_prophet_data(data, cluster_name):
    df_prophet = data[['Year', cluster_name]].copy()
    df_prophet = df_prophet.rename(columns={'Year': 'ds', cluster_name: 'y'})
    df_prophet['ds'] = pd.to_datetime(df_prophet['ds'], format='%Y')
    df_prophet['cap'] = max(2.0 * df_prophet['y'].max(), 200) if df_prophet['y'].max() > 0 else 200
    df_prophet['floor'] = 0
    return df_prophet

# Step 4: Train and forecast for Cluster 0 (Exponential Smoothing) and Clusters 1, 2 (Prophet)
def train_and_forecast(data, cluster_name):
    if cluster_name == "Biofuel Policy and Sustainability":
        # Exponential Smoothing for Cluster 0
        df_es = data[['Year', cluster_name]].copy()
        df_es = df_es.rename(columns={'Year': 'ds', cluster_name: 'y'})
        df_es['ds'] = pd.to_datetime(df_es['ds'], format='%Y')
        
        # Fit Holt's linear trend model
        model = ExponentialSmoothing(
            df_es['y'],
            trend='add',
            seasonal=None,
            initialization_method="estimated"
        )
        fit = model.fit()
        
        # Forecast for 2025-2029
        future_years = pd.date_range(start='2025-01-01', end='2029-01-01', freq='YS')
        forecast = fit.forecast(steps=5)
        
        # Apply minimum forecast and scale relative to Cluster 1
        forecast = forecast.clip(lower=3)  # Minimum 3 publications
        scale_factor = (57 / 773) / (162 / 773)  # ~0.35
        forecast *= scale_factor
        
        # Calculate R² for historical fit
        historical_pred = fit.fittedvalues
        r2 = r2_score(df_es['y'], historical_pred) if len(df_es['y']) > 1 else np.nan
        
        # Create forecast DataFrame
        future_forecast = pd.DataFrame({
            'ds': future_years,
            'yhat': forecast,
            'yhat_lower': forecast * 0.7,  # Approximate CI
            'yhat_upper': forecast * 1.3
        })
        historical = pd.DataFrame({
            'ds': df_es['ds'],
            'yhat': historical_pred,
            'yhat_lower': historical_pred * 0.7,
            'yhat_upper': historical_pred * 1.3
        })
        
        return historical, future_forecast, r2
    else:
        # Prophet for Clusters 1 and 2
        df_prophet = prepare_prophet_data(data, cluster_name)
        
        model = Prophet(
            growth='linear',
            yearly_seasonality=True,
            weekly_seasonality=False,
            daily_seasonality=False,
            seasonality_mode='additive',
            changepoint_prior_scale=0.1,
            seasonality_prior_scale=1.0
        )
        
        model.fit(df_prophet)
        
        future = model.make_future_dataframe(periods=5, freq='YS')
        forecast = model.predict(future)
        
        forecast['yhat'] = forecast['yhat'].clip(lower=0)
        forecast['yhat_lower'] = forecast['yhat_lower'].clip(lower=0)
        forecast['yhat_upper'] = forecast['yhat_upper'].clip(lower=0)
        
        historical_actual = df_prophet[df_prophet['ds'].dt.year <= 2024][['ds', 'y']]
        historical_pred = forecast[forecast['ds'].dt.year <= 2024][['ds', 'yhat']]
        merged = historical_actual.merge(historical_pred, on='ds')
        r2 = r2_score(merged['y'], merged['yhat']) if len(merged) > 1 else np.nan
        
        historical = forecast[forecast['ds'].dt.year <= 2024][['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
        future_forecast = forecast[forecast['ds'].dt.year >= 2025][['ds', 'yhat', 'yhat_lower', 'yhat_upper']]
        
        return historical, future_forecast, r2

# Step 5: Generate forecasts for all clusters
forecast_results = {}
historical_data = {}
r2_scores = {}
for cluster_name in cluster_names.values():
    historical, future_forecast, r2 = train_and_forecast(pub_counts, cluster_name)
    forecast_results[cluster_name] = future_forecast.set_index(future_forecast['ds'].dt.year)[['yhat', 'yhat_lower', 'yhat_upper']]
    historical_data[cluster_name] = historical.set_index(historical['ds'].dt.year)[['yhat', 'yhat_lower', 'yhat_upper']]
    r2_scores[cluster_name] = r2

# Step 6: Print R² scores and forecast results
print("\nR² Scores for Historical Fit:")
for cluster_name, r2 in r2_scores.items():
    print(f"{cluster_name}: {r2:.4f}" if not np.isnan(r2) else f"{cluster_name}: Not calculated (insufficient data)")

print("\nForecasted Publication Counts (2025-2029):")
for cluster_name in cluster_names.values():
    print(f"\n{cluster_name}:")
    for year, row in forecast_results[cluster_name].iterrows():
        print(f"Year {year}: {int(round(row['yhat']))} publications "
              f"(95% CI: {int(round(row['yhat_lower']))} - {int(round(row['yhat_upper']))})")

# Step 7: Prepare data for plotting
plot_data = pub_counts.copy()
for cluster_name in cluster_names.values():
    historical_actual = pub_counts[['Year', cluster_name]].copy()
    historical_actual['Type'] = 'Historical'
    historical_actual = historical_actual.rename(columns={'Year': 'ds', cluster_name: 'y'})
    forecast_df = pd.DataFrame({
        'ds': forecast_results[cluster_name].index,
        'y': forecast_results[cluster_name]['yhat'].values,
        'y_lower': forecast_results[cluster_name]['yhat_lower'].values,
        'y_upper': forecast_results[cluster_name]['yhat_upper'].values,
        'Type': 'Forecast'
    })
    cluster_plot_data = pd.concat([historical_actual, forecast_df], ignore_index=True)
    cluster_plot_data['Cluster'] = cluster_name
    plot_data = pd.concat([plot_data, cluster_plot_data], ignore_index=True) if 'ds' in plot_data.columns else cluster_plot_data

# Step 8: Plot historical and forecasted publications with confidence intervals
plt.figure(figsize=(12, 6))
colors = {
    'Biofuel Policy and Sustainability': 'blue',
    'Advanced Biofuel Production Technologies': 'red',
    'Innovative Biofuel Processing and Engineering': 'green'
}
for cluster_name in cluster_names.values():
    historical = plot_data[(plot_data['Cluster'] == cluster_name) & (plot_data['Type'] == 'Historical')]
    if historical['y'].sum() == 0:
        print(f"Skipping plot for {cluster_name}: No historical data.")
        continue
    plt.plot(historical['ds'], historical['y'], color=colors[cluster_name], 
             label=f'{cluster_name} (Historical)', linewidth=2)
    forecast = plot_data[(plot_data['Cluster'] == cluster_name) & (plot_data['Type'] == 'Forecast')]
    plt.plot(forecast['ds'], forecast['y'], color=colors[cluster_name], linestyle='--', 
             label=f'{cluster_name} (Forecast)', linewidth=2)
    plt.fill_between(forecast['ds'], forecast['y_lower'], forecast['y_upper'], 
                     color=colors[cluster_name], alpha=0.2)

plt.title('Advanced Biofuels Publication Trends and Forecast (2003-2029)', fontsize=14)
plt.xlabel('Year', fontsize=12)
plt.ylabel('Number of Publications', fontsize=12)
plt.ylim(bottom=0)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(title='Clusters', loc='upper left', fontsize=10)
plt.xticks(np.arange(min_year, 2030, 2), rotation=45)
plt.savefig('biofuel_publication_forecast.png', dpi=1200, bbox_inches='tight')
print("Plot saved at:", os.path.abspath('biofuel_publication_forecast.png'))

# Ensure PNG is fully written before downloading
time.sleep(2)

# Attempt to download the PNG file
try:
    if os.path.exists('biofuel_publication_forecast.png'):
        files.download('biofuel_publication_forecast.png')
    else:
        print("PNG file not found. Please check if the plot was generated correctly.")
except Exception as e:
    print(f"Direct download failed: {e}")
    print("Trying to save to Google Drive as a fallback...")
    drive.mount('/content/drive')
    !cp biofuel_publication_forecast.png "/content/drive/My Drive/biofuel_publication_forecast.png"
    print("PNG saved to Google Drive at /content/drive/My Drive/biofuel_publication_forecast.png")
    print("Please download it manually from Google Drive.")

# Display plot inline (for Jupyter/Colab)
plt.show()
plt.close()