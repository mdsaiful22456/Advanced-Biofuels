import pandas as pd
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import hdbscan
import umap
import matplotlib.pyplot as plt
import re
import warnings
import time
from google.colab import files
from google.colab import drive

# Suppress warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message="n_jobs value .* overridden to 1 by setting random_state")

# Verify umap-learn installation
try:
    from umap import UMAP
except ImportError:
    raise ImportError("The 'umap-learn' package is not installed. Please install it using: pip install umap-learn")

# Load the dataset
df = pd.read_csv('advanced biofuel.csv')

# Combine relevant textual fields for analysis
df['combined_text'] = df['Title'].fillna('') + ' ' + df['Abstract'].fillna('') + ' ' + df['Author Keywords'].fillna('')

# Minimal preprocessing function (SciBERT handles most text processing)
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\s+', ' ', text.strip())  # Normalize whitespace
    return text

# Apply preprocessing
df['processed_text'] = df['combined_text'].apply(preprocess_text)

# Load SciBERT tokenizer and model
tokenizer = AutoTokenizer.from_pretrained('allenai/scibert_scivocab_uncased')
model = AutoModel.from_pretrained('allenai/scibert_scivocab_uncased')

# Function to get SciBERT embeddings
def get_scibert_embeddings(texts, batch_size=8, device='cpu'):
    embeddings = []
    model.to(device)
    model.eval()
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i + batch_size]
        inputs = tokenizer(batch_texts, return_tensors='pt', truncation=True, padding=True, max_length=512)
        inputs = {k: v.to(device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = model(**inputs)
        # Use the [CLS] token embedding (first token)
        batch_embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
        embeddings.append(batch_embeddings)
    return np.vstack(embeddings)

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Get SciBERT embeddings
texts = df['processed_text'].tolist()
embeddings = get_scibert_embeddings(texts, device=device)

# Standardize embeddings
scaler = StandardScaler()
embeddings_scaled = scaler.fit_transform(embeddings)

# Reduce dimensionality with UMAP (tuned parameters)
umap_reducer = UMAP(n_components=2, random_state=42, n_neighbors=30, min_dist=0.3)
umap_embeddings = umap_reducer.fit_transform(embeddings_scaled)

# Cluster with HDBSCAN (tuned parameters)
clusterer = hdbscan.HDBSCAN(min_cluster_size=2, min_samples=2, cluster_selection_epsilon=0.7)
clusters = clusterer.fit_predict(umap_embeddings)

# Post-process to assign noise points to nearest cluster
def assign_noise_to_clusters(clusters, umap_embeddings):
    if -1 in clusters:
        noise_indices = np.where(clusters == -1)[0]
        if len(noise_indices) > 0:
            # Get non-noise clusters
            valid_clusters = np.unique(clusters[clusters != -1])
            if len(valid_clusters) == 0:
                return clusters  # No valid clusters to assign to
            # Compute centroids for each valid cluster
            centroids = {c: np.mean(umap_embeddings[clusters == c], axis=0) for c in valid_clusters}
            # Assign each noise point to the nearest cluster
            for idx in noise_indices:
                distances = [np.linalg.norm(umap_embeddings[idx] - centroids[c]) for c in valid_clusters]
                nearest_cluster = valid_clusters[np.argmin(distances)]
                clusters[idx] = nearest_cluster
    return clusters

# Apply noise reassignment
clusters = assign_noise_to_clusters(clusters, umap_embeddings)

# Calculate silhouette score
def calculate_silhouette_score(embeddings, clusters):
    unique_clusters = np.unique(clusters)
    if len(unique_clusters) < 2:
        print("\nSilhouette Score: Not calculated (fewer than 2 clusters).")
        return None, None
    # Compute overall silhouette score
    score = silhouette_score(embeddings, clusters)
    # Compute per-cluster silhouette scores
    per_cluster_scores = {}
    for cluster in unique_clusters:
        cluster_mask = clusters == cluster
        if np.sum(cluster_mask) > 1:  # Need at least 2 points for silhouette
            cluster_score = silhouette_score(embeddings, clusters, sample_size=None, metric='euclidean')
            per_cluster_scores[cluster] = cluster_score
    return score, per_cluster_scores

# Compute and print silhouette score
sil_score, sil_scores_per_cluster = calculate_silhouette_score(umap_embeddings, clusters)
if sil_score is not None:
    print("\nOverall Silhouette Score:", round(sil_score, 4))
    print("Per-Cluster Silhouette Scores:")
    for cluster, score in sil_scores_per_cluster.items():
        print(f"Cluster {cluster}: {round(score, 4)}")

# Find representative documents for each cluster
def get_representative_docs(df, embeddings, clusters, n_reps=5):
    unique_clusters = np.unique(clusters)
    representatives = {}
    
    for cluster in unique_clusters:
        # Get indices of documents in this cluster
        cluster_indices = np.where(clusters == cluster)[0]
        # Get embeddings for this cluster
        cluster_embeddings = embeddings[cluster_indices]
        # Calculate centroid
        centroid = np.mean(cluster_embeddings, axis=0)
        # Calculate Euclidean distances to centroid
        distances = np.linalg.norm(cluster_embeddings - centroid, axis=1)
        # Get indices of the n_reps closest documents
        closest_indices = cluster_indices[np.argsort(distances)[:n_reps]]
        # Store titles and indices
        representatives[cluster] = df.iloc[closest_indices][['Title']].reset_index(drop=True)
    
    return representatives

# Get 5 representative documents per cluster
rep_docs = get_representative_docs(df, umap_embeddings, clusters, n_reps=5)

# Print representative documents
print("\nRepresentative Documents for Each Cluster:")
for cluster, docs in rep_docs.items():
    print(f"\nCluster {cluster}:")
    for i, title in enumerate(docs['Title'], 1):
        print(f"{i}. {title}")

# Visualize the results with custom colors
plt.figure(figsize=(10, 8))
unique_clusters = np.unique(clusters)
colors = ['red', 'green', 'blue', 'yellow', 'purple']  # Custom color palette
for i, cluster in enumerate(unique_clusters):
    mask = clusters == cluster
    label = f'Cluster {cluster}'
    count = np.sum(mask)
    # Cycle through colors if there are more clusters than colors
    color = colors[i % len(colors)]
    plt.scatter(umap_embeddings[mask, 0], umap_embeddings[mask, 1], c=[color], label=f'{label} (n={count})', s=80, alpha=0.6)
plt.title('UMAP Visualization of Advanced Biofuels Research Clusters (SciBERT + HDBSCAN)', fontsize=14)
plt.xlabel('UMAP Component 1', fontsize=12)
plt.ylabel('UMAP Component 2', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(title='Clusters', loc='best')
# Save the plot as a high-quality PNG
plt.savefig('biofuel_scibert_clusters.png', dpi=1200, bbox_inches='tight')
plt.close()

# Ensure PNG is fully written before downloading
time.sleep(2)

# Attempt to download the PNG file
try:
    files.download('biofuel_scibert_clusters.png')
except Exception as e:
    print(f"Direct download failed: {e}")
    print("Trying to save to Google Drive as a fallback...")
    # Mount Google Drive
    drive.mount('/content/drive')
    # Copy PNG to Google Drive
    !cp biofuel_scibert_clusters.png "/content/drive/My Drive/biofuel_scibert_clusters.png"
    print("PNG saved to Google Drive at /content/drive/My Drive/biofuel_scibert_clusters.png")
    print("Please download it manually from Google Drive.")

# Add cluster labels to the dataframe for further analysis
df['cluster'] = clusters
# Print the first few titles with their cluster labels
print(df[['Title', 'cluster']].head(10))
# Print the number of points in each cluster
cluster_counts = df['cluster'].value_counts().sort_index()
print("\nCluster Counts:")
print(cluster_counts)