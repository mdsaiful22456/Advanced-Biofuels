import pandas as pd
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import re
from tqdm import tqdm
import math

# Download NLTK resources (run once)
nltk.download('punkt')
nltk.download('stopwords')

# Initialize stopwords
stop_words = set(stopwords.words('english')).union({
    'study', 'research', 'using', 'used', 'via', 'can', 'gas', 'copyright',
    'elsevier', 'article', 'ltd', 'nonhuman', 'author', 'respect', 'process',
    'journal', 'priority', 'springer', 'wiley', 'published'
})

# Synonym mapping
synonym_map = {
    'biofuel': 'biofuel',
    'biofuels': 'biofuel',
    'advanced biofuel': 'biofuel',
    'advanced biofuels': 'biofuel',
    'fatty acid': 'fatty acid',
    'fatty acids': 'fatty acid',
    'cellulose': 'cellulose',
    'cellulosic': 'cellulose',
    'metabolic engineering': 'metabolic engineering',
    'anaerobic digestion': 'anaerobic digestion',
    'ghg emission': 'ghg emission',
    'ghg emissions': 'ghg emission',
    'biofuel production': 'biofuel production',
    'lignocellulosic biomass': 'lignocellulosic biomass'
}

# Function to clean phrases
def clean_phrase(phrase):
    # Remove punctuation except spaces and hyphens
    cleaned = re.sub(r'[^a-z0-9 -]', '', phrase.lower()).strip()
    if not cleaned or re.match(r'^[\W\d]+$', cleaned):
        return None
    words = cleaned.split()
    # Exclude stopwords but preserve multi-word phrases
    filtered = [word for word in words if word not in stop_words]
    if not filtered:
        return None
    return ' '.join(filtered)

# Read dataset
df = pd.read_csv('advanced biofuel.csv', low_memory=False)

# Inspect Year column
print("Unique values in Year column:")
invalid_years = df[~df['Year'].astype(str).str.match(r'^\d{4}$')]['Year'].unique()
print(f"Invalid Year values: {invalid_years}")
print(df['Year'].value_counts(dropna=False))

# Clean Year column
df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
df = df.dropna(subset=['Year'])
df['Year'] = df['Year'].astype(int)
df = df[(df['Year'] >= 2000) & (df['Year'] <= 2024)]

# Report data
print(f"Number of rows after cleaning: {len(df)}")
print(f"Year range: {df['Year'].min()} to {df['Year'].max()}")

# Clean text columns
df['Abstract'] = df['Abstract'].fillna('').str.lower().str.strip()
df['Author Keywords'] = df['Author Keywords'].fillna('').str.lower().str.strip()
df['Index Keywords'] = df['Index Keywords'].fillna('').str.lower().str.strip()

# Filter rows with non-empty keyword fields
df = df[df[['Abstract', 'Author Keywords', 'Index Keywords']].ne('').any(axis=1)]

# Tokenize and process keywords
keywords_list = []

# 1. Abstract (bigrams)
for _, row in df.iterrows():
    year = row['Year']
    text = row['Abstract']
    if text:
        words = word_tokenize(text)
        bigrams = [' '.join(words[i:i+2]) for i in range(len(words)-1)]
        for bigram in bigrams:
            cleaned = clean_phrase(bigram)
            if cleaned and len(cleaned.split()) == 2:  # Ensure valid bigram
                keywords_list.append({'Year': year, 'Keyword': cleaned})

# 2. Author Keywords (semicolon-separated)
for _, row in df.iterrows():
    year = row['Year']
    keywords = row['Author Keywords']
    if keywords:
        cleaned = re.sub(r'[^a-z0-9; -]', '', keywords)
        for kw in cleaned.split(';'):
            kw = kw.strip()
            cleaned = clean_phrase(kw)
            if cleaned:
                keywords_list.append({'Year': year, 'Keyword': cleaned})

# 3. Index Keywords (semicolon-separated)
for _, row in df.iterrows():
    year = row['Year']
    keywords = row['Index Keywords']
    if keywords:
        cleaned = re.sub(r'[^a-z0-9; -]', '', keywords)
        for kw in cleaned.split(';'):
            kw = kw.strip()
            cleaned = clean_phrase(kw)
            if cleaned:
                keywords_list.append({'Year': year, 'Keyword': cleaned})

# Create keywords dataframe
keywords_df = pd.DataFrame(keywords_list)

# Apply synonym mapping
keywords_df['Keyword'] = keywords_df['Keyword'].map(lambda x: synonym_map.get(x, x))

# Filter low-frequency keywords
keyword_counts = keywords_df['Keyword'].value_counts()
valid_keywords = keyword_counts[keyword_counts >= 10].index  # At least 10 occurrences
keywords_df = keywords_df[keywords_df['Keyword'].isin(valid_keywords)]

# Calculate yearly frequencies
keyword_yearly = keywords_df.groupby(['Keyword', 'Year']).size().reset_index(name='Frequency')
keyword_yearly = keyword_yearly.pivot(index='Keyword', columns='Year', values='Frequency').fillna(0)
keyword_yearly = keyword_yearly.reset_index()

# Ensure all years 2000-2024
all_years = list(range(2000, 2025))
missing_years = [y for y in all_years if y not in keyword_yearly.columns]
for year in missing_years:
    keyword_yearly[year] = 0
keyword_yearly = keyword_yearly[['Keyword'] + all_years]

# Burst detection function
def detect_bursts(row):
    freqs = row[all_years].values
    keyword = row['Keyword']
    
    # Baseline: Median frequency across all years
    baseline = np.median(freqs)
    if baseline == 0:
        baseline = 0.5  # Avoid extreme strengths
    
    # Identify bursts: Frequency >= 2 * baseline
    is_burst = freqs >= 2 * baseline
    
    # Find burst periods
    bursts = []
    start = None
    for i, burst in enumerate(is_burst):
        if burst and start is None:
            start = 2000 + i
        elif not burst and start is not None:
            end = 2000 + i - 1
            if end - start + 1 >= 2:
                burst_freq = sum(freqs[start-2000:end-2000+1])
                strength = (burst_freq / (baseline * (end - start + 1))) * math.log(end - start + 2)
                bursts.append({'Start': start, 'End': end, 'Strength': strength})
            start = None
    if start is not None:
        end = 2024
        if end - start + 1 >= 2:
            burst_freq = sum(freqs[start-2000:end-2000+1])
            strength = (burst_freq / (baseline * (end - start + 1))) * math.log(end - start + 2)
            bursts.append({'Start': start, 'End': end, 'Strength': strength})
    
    if not bursts:
        return None
    
    # Select strongest burst
    strongest = max(bursts, key=lambda x: x['Strength'])
    recent_freq = sum(freqs[2019-2000:2025-2000])
    return pd.Series({
        'Keyword': keyword,
        'Start_Time': strongest['Start'],
        'End_Time': strongest['End'],
        'Burst_Strength': strongest['Strength'],
        'Recent_Frequency': recent_freq
    })

# Apply burst detection
burst_results = []
for _, row in tqdm(keyword_yearly.iterrows(), total=len(keyword_yearly), desc="Detecting bursts"):
    result = detect_bursts(row)
    if result is not None:
        burst_results.append(result)

burst_results = pd.DataFrame(burst_results)

# Top 20 by burst strength
top_20_bursts = burst_results.sort_values('Burst_Strength', ascending=False).head(20)

# Top 5 by recent frequency
top_5_recent = burst_results.sort_values('Recent_Frequency', ascending=False).head(5)
top_5_recent['Trend'] = top_5_recent['End_Time'].apply(
    lambda x: 'Likely to continue' if x >= 2023 else
              'May stabilize' if x >= 2020 else
              'Likely to decline'
)

# Print results
print("\nTop 20 Burst Keywords by Burst Strength:")
print(top_20_bursts.to_string(index=False))

print("\nTop 5 Keywords by Recent Frequency (2019-2024) with Trends:")
print(top_5_recent.to_string(index=False))

# Save to CSV
top_20_bursts.to_csv('top_20_burst_keywords.csv', index=False)