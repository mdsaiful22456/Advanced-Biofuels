# Loading required libraries
library(dplyr)
library(tidyr)
library(tidytext)
library(tm)
library(SnowballC)

# Reading the dataset
csv_data <- read.csv("advanced biofuel.csv", stringsAsFactors = FALSE)

# Defining stopwords (English stopwords + custom additions)
stop_words <- c(tm::stopwords("english"), "study", "research", "using", "used", "via", "can", "gas")

# Defining synonym mapping for repetitive terms
synonym_map <- c(
  "biofuel" = "biofuel",
  "biofuels" = "biofuel",
  "advanced biofuel" = "biofuel",
  "advanced biofuels" = "biofuel"
)

# Function to stem phrases (split, stem each word, rejoin)
stem_phrase <- function(phrase) {
  words <- unlist(strsplit(phrase, " "))
  stemmed <- sapply(words, wordStem, language = "english")
  paste(stemmed, collapse = " ")
}

# Cleaning and preparing data
keyword_data <- csv_data %>%
  mutate(
    Abstract = trimws(tolower(Abstract)),                        # Clean Abstract
    Author.Keywords = trimws(tolower(Author.Keywords)),         # Clean Author Keywords
    Index.Keywords = trimws(tolower(Index.Keywords)),           # Clean Index Keywords
    # Replace NA with empty string
    Abstract = if_else(is.na(Abstract), "", Abstract),
    Author.Keywords = if_else(is.na(Author.Keywords), "", Author.Keywords),
    Index.Keywords = if_else(is.na(Index.Keywords), "", Index.Keywords)
  ) %>%
  filter(Abstract != "" | Author.Keywords != "" | Index.Keywords != "")  # Remove rows with all empty keyword fields

# Combining and tokenizing keywords
# 1. Tokenize Abstract (split into bigrams)
abstract_bigrams <- keyword_data %>%
  select(Abstract) %>%
  unnest_tokens(bigram, Abstract, token = "ngrams", n = 2) %>%
  # Separate bigrams into two words for stopword filtering
  separate(bigram, c("word1", "word2"), sep = " ") %>%
  filter(
    !word1 %in% stop_words, !word2 %in% stop_words,           # Remove bigrams with stopwords
    !grepl("^[0-9]+$", word1), !grepl("^[0-9]+$", word2)      # Remove bigrams with numbers
  ) %>%
  # Recombine and stem bigrams
  unite(bigram, word1, word2, sep = " ") %>%
  mutate(bigram = sapply(bigram, stem_phrase)) %>%
  filter(bigram != "")

# 2. Tokenize Author Keywords (split by semicolon)
author_keywords <- keyword_data %>%
  select(Author.Keywords) %>%
  mutate(Author.Keywords = gsub("[^a-z0-9; -]", "", Author.Keywords)) %>%  # Remove punctuation except semicolon, space, hyphen
  unnest_tokens(keyword, Author.Keywords, token = "regex", pattern = ";\\s*") %>%
  filter(keyword != "", !keyword %in% stop_words) %>%
  # Stem keywords
  mutate(keyword = sapply(keyword, stem_phrase))

# 3. Tokenize Index Keywords (split by semicolon)
index_keywords <- keyword_data %>%
  select(Index.Keywords) %>%
  mutate(Index.Keywords = gsub("[^a-z0-9; -]", "", Index.Keywords)) %>%  # Fixed: Added replacement string ""
  unnest_tokens(keyword, Index.Keywords, token = "regex", pattern = ";\\s*") %>%
  filter(keyword != "", !keyword %in% stop_words) %>%
  # Stem keywords
  mutate(keyword = sapply(keyword, stem_phrase))

# Combining all keywords (bigrams from Abstract, phrases from Author/Index Keywords)
all_keywords <- bind_rows(
  abstract_bigrams %>% rename(keyword = bigram),
  author_keywords,
  index_keywords
)

# Applying synonym mapping
all_keywords <- all_keywords %>%
  mutate(keyword = ifelse(keyword %in% names(synonym_map), synonym_map[keyword], keyword))

# Counting keyword occurrences
keyword_counts <- all_keywords %>%
  group_by(keyword) %>%
  summarise(Occurrences = n()) %>%
  arrange(desc(Occurrences)) %>%
  slice_head(n = 10)  # Select top 10 keywords

# Printing results
print("Top 10 Keywords (Stemmed and Merged) by Occurrence:")
print(keyword_counts)

# Saving results to CSV
write.csv(keyword_counts, "top_10_keywords_stemmed.csv", row.names = FALSE)